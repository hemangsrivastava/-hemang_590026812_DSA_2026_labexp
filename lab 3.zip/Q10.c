#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct node{
	int roll;
	char name[30];
	float marks;
	struct node *next;
};

int main(){
	int ch,r;
	struct node *head=NULL,*temp,*prev,*newnode;
	
	while(1){
		printf("\n1.Insert 2.Delete 3.Search 4.Display 5.Exit\n");
		scanf("%d",&ch);
		
		if(ch==1){   // Insert
			newnode=(struct node*)malloc(sizeof(struct node));
			printf("Enter roll name marks:");
			scanf("%d%s%f",&newnode->roll,newnode->name,&newnode->marks);
			newnode->next=NULL;
			
			if(head==NULL) head=newnode;
			else{
				temp=head;
				while(temp->next) temp=temp->next;
				temp->next=newnode;
			}
		}
		else if(ch==2){   // Delete
			printf("Enter roll to delete:");
			scanf("%d",&r);
			temp=head; prev=NULL;
			
			while(temp && temp->roll!=r){
				prev=temp;
				temp=temp->next;
			}
			
			if(temp==NULL) printf("Not found");
			else{
				if(prev==NULL) head=temp->next;
				else prev->next=temp->next;
				free(temp);
				printf("Deleted");
			}
		}
		else if(ch==3){   // Search
			printf("Enter roll to search:");
			scanf("%d",&r);
			temp=head;
			
			while(temp && temp->roll!=r)
			temp=temp->next;
			
			if(temp)
			printf("Roll:%d Name:%s Marks:%.2f",
			temp->roll,temp->name,temp->marks);
			else
			printf("Not found");
		}
		else if(ch==4){   // Display
			temp=head;
			while(temp){
				printf("Roll:%d Name:%s Marks:%.2f\n",
				temp->roll,temp->name,temp->marks);
				temp=temp->next;
			}
		}
		else if(ch==5)
		break;
	}
	return 0;
}
