#include <stdio.h>
#include <stdlib.h>

struct node{
	int data;
	struct node *next;
};

int main(){
	int i,n,value,count=0,tempdata;
	struct node *head=NULL,*temp=NULL,*newnode,*ptr1,*ptr2;
	
	printf("Enter number of nodes:");
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		printf("Enter data:");
		scanf("%d",&value);
		
		newnode=(struct node*)malloc(sizeof(struct node));  // create node
		newnode->data=value;
		newnode->next=NULL;
		
		if(head==NULL)
		{
			head=newnode;   // first node
			temp=newnode;
		}
		else
		{
			temp->next=newnode;   // link node
			temp=newnode;
		}
	}
	
	/* Count number of nodes */
	temp=head;
	while(temp!=NULL)
	{
		count++;
		temp=temp->next;
	}
	
	/* Reverse data using two pointers */
	for(i=0;i<count/2;i++)
	{
		ptr1=head;
		ptr2=head;
		
		for(int j=0;j<i;j++)      // move ptr1 forward
		ptr1=ptr1->next;
		
		for(int j=0;j<count-i-1;j++)  // move ptr2 to opposite end
		ptr2=ptr2->next;
		
		tempdata=ptr1->data;     // swap data
		ptr1->data=ptr2->data;
		ptr2->data=tempdata;
	}
	
	printf("Linked list after reversing data:\n");
	temp=head;
	while(temp!=NULL)
	{
		printf("%d ",temp->data);
		temp=temp->next;
	}
	
	return 0;
}
