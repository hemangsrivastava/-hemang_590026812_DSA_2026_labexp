#include <stdio.h>
#include <stdlib.h>

struct node{
	int data;
	struct node *next;
};

int main(){
	int i,n,value,count=0;   // count for number of nodes
	struct node *head=NULL,*temp=NULL,*newnode;
	
	printf("Enter number of nodes:");
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		printf("Enter data:");
		scanf("%d",&value);
		
		newnode=(struct node*)malloc(sizeof(struct node));  // create node
		newnode->data=value;
		newnode->next=NULL;
		
		if(head==NULL)
		{
			head=newnode;      // first node
			temp=newnode;
		}
		else
		{
			temp->next=newnode;  // link node
			temp=newnode;
		}
	}
	temp=head;   // start traversal
	while(temp!=NULL)
	{
		count++;        // increment count
		temp=temp->next;   // move to next node
	}
	printf("Total number of nodes:%d",count);
	return 0;
}
