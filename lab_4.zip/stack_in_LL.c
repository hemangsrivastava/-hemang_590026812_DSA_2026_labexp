#include<stdio.h>
#include<stdlib.h>

struct node{int data; struct node*next;}*top=NULL;

void push(int val){
    struct node*newnode;
    newnode=(struct node*)malloc(sizeof(struct node));
    newnode->data=val;
    newnode->next=top;
    top=newnode;
}

void pop(){
    struct node*temp;
    if(top==NULL) printf("Underflow\n");
    else{
        temp=top;
        printf("Deleted: %d\n",temp->data);
        top=top->next;
        free(temp);
    }
}

void display(){
    struct node*temp;
    temp=top;
    while(temp){
        printf("%d ",temp->data);
        temp=temp->next;
    }
    printf("\n");
}

int main(){
    int ch,val;
    while(1){
        printf("1.Push 2.Pop 3.Display 4.Exit\n");
        scanf("%d",&ch);
        switch(ch){
            case 1: scanf("%d",&val); push(val); break;
            case 2: pop(); break;
            case 3: display(); break;
            case 4: return 0;
        }
    }
}
