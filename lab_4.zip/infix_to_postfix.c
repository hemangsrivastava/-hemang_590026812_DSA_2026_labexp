#include<stdio.h>
#include<ctype.h>

char stack[100];
int top=-1;

void push(char c){ stack[++top]=c; }
char pop(){ return stack[top--]; }

int prec(char c){
    if(c=='^') return 3;
    if(c=='*'||c=='/') return 2;
    if(c=='+'||c=='-') return 1;
    return 0;
}

int main(){
    char infix[100],postfix[100];
    int i,j=0;

    scanf("%s",infix);

    for(i=0;infix[i];i++){
        if(isalnum(infix[i])) postfix[j++]=infix[i];
        else if(infix[i]=='(') push(infix[i]);
        else if(infix[i]==')'){
            while(stack[top]!='(') postfix[j++]=pop();
            pop();
        }else{
            while(top!=-1 && prec(stack[top])>=prec(infix[i]))
                postfix[j++]=pop();
            push(infix[i]);
        }
    }

    while(top!=-1) postfix[j++]=pop();
    postfix[j]='\0';

    printf("%s",postfix);
}
