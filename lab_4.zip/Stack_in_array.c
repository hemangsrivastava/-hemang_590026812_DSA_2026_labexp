#include<stdio.h>
#define MAX 100

int stack[MAX], top=-1;

void push(int val){
    if(top==MAX-1) printf("Overflow\n");
    else stack[++top]=val;
}

void pop(){
    if(top==-1) printf("Underflow\n");
    else printf("Deleted: %d\n",stack[top--]);
}

void display(){
    int i;
    if(top==-1) printf("Empty\n");
    else{
        for(i=top;i>=0;i--) printf("%d ",stack[i]);
        printf("\n");
    }
}

int main(){
    int ch,val;
    while(1){
        printf("1.Push 2.Pop 3.Display 4.Exit\n");
        scanf("%d",&ch);
        switch(ch){
            case 1: scanf("%d",&val); push(val); break;
            case 2: pop(); break;
            case 3: display(); break;
            case 4: return 0;
        }
    }
}
