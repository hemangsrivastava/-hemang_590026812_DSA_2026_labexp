#include<stdio.h>

int fac(int n){
if(n==1){
return 1;
}else{
return n*fac(n-1);
}
}

int main(){
int x;
printf("ENTER THE NUMBER\n");
scanf("%d",&x);
x=fac(x);
printf("FACTORIAL:%d",x);
return 0;
}

