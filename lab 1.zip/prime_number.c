/*Write a program to check if a number is prime.*/
#include <stdio.h>
int main(){
int a,i,c=0; 
printf("enter the number: ");
scanf("%d",&a);
for (i=1;i<=a;i++){
if (a % i ==0){
c++;}}
if (c==2){
printf("Prime Number");}
else{
printf("Not Prime Number");}
return 0;
}
