#include<stdio.h>
#include<stdlib.h>
int main(){
int n,i,j;
int**a,**b,**add,**sub;
printf("enter the order of matrix: ");
scanf("%d",&n);
a=(int**)malloc(n*sizeof(int*));
b=(int**)malloc(n*sizeof(int*));
add=(int**)malloc(n*sizeof(int*));
sub=(int**)malloc(n*sizeof(int*));
for(i=0;i<n;i++){
a[i]=(int*)malloc(n*sizeof(int));
b[i]=(int*)malloc(n*sizeof(int));
add[i]=(int*)malloc(n*sizeof(int));
sub[i]=(int*)malloc(n*sizeof(int));
}
printf("enter elements of matrix A:\n");
for(i=0;i<n;i++)
for(j=0;j<n;j++)
scanf("%d",&a[i][j]);
printf("enter elements of matrix B:\n");
for(i=0;i<n;i++)
for(j=0;j<n;j++)
scanf("%d",&b[i][j]);
for(i=0;i<n;i++)
for(j=0;j<n;j++){
add[i][j]=a[i][j]+b[i][j];
sub[i][j]=a[i][j]-b[i][j];
}
printf("addition matrix:\n");
for(i=0;i<n;i++){
for(j=0;j<n;j++)printf("%d ",add[i][j]);
printf("\n");
}
printf("subtraction matrix:\n");
for(i=0;i<n;i++){
for(j=0;j<n;j++)printf("%d ",sub[i][j]);
printf("\n");
}
for(i=0;i<n;i++){
free(a[i]);
free(b[i]);
free(add[i]);
free(sub[i]);
}
free(a);
free(b);
free(add);
free(sub);
return 0;
}

