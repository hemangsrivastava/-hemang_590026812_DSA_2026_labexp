#include <stdio.h>
#include <stdlib.h>

struct rec{
	int x;
};

int main(){
	struct rec *r=NULL;
	int ch,n=0,i;

	while(1)
	{
		printf("\n1.Add 2.Display 3.Delete 4.Exit\n");
		scanf("%d",&ch);

		if(ch==1)
		{
			n++;
			r = realloc(r,n*sizeof(struct rec));
			printf("Enter value:");
			scanf("%d",&r[n-1].x);
		}
		else if(ch==2)
		{
			for(i=0;i<n;i++)
				printf("%d ", r[i].x);
		}
		else if(ch==3)
		{
			if(n>0)
				n--;
			r=realloc(r,n*sizeof(struct rec));
		}
		else
		{
			free(r);
			return 0;
		}
	}
}

