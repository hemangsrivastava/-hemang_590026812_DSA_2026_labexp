#include <stdio.h>
#include <stdlib.h>

struct student{
	int roll;
	float marks;
};

int main(){
	int n,i,j;
	struct student *s,t;

	printf("Enter number of students:");
	scanf("%d",&n);

	s=(struct student*)malloc(n*sizeof(struct student));

	for(i=0;i<n;i++){
		printf("Enter roll and marks:");
		scanf("%d %f",&s[i].roll,&s[i].marks);
	}

	for(i=0;i<n-1;i++){
		for(j=i+1;j<n;j++){
			if(s[i].marks>s[j].marks){
				t = s[i];
				s[i] = s[j];
				s[j] = t;
			}
		}
	}

	printf("Sorted list:\n");
	for(i=0;i<n;i++)
		printf("Roll:%d Marks:%.2f\n",s[i].roll,s[i].marks);

	free(s);
	return 0;
}

