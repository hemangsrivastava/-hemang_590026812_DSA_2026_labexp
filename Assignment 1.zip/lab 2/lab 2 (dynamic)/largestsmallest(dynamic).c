#include<stdio.h>
#include<stdlib.h>
int main(){
int n,i,max,min;
int*arr;
printf("enter the number of elements: ");
scanf("%d",&n);
arr=(int*)malloc(n*sizeof(int));
for(i=0;i<n;i++)
scanf("%d",&arr[i]);
max=arr[0];
min=arr[0];
for(i=0;i<n;i++){
if(arr[i]>max)max=arr[i];
}
for(i=0;i<n;i++){
if(arr[i]<min)min=arr[i];
}
printf("maximum is: %d\n",max);
printf("minimum is: %d\n",min);
free(arr);
arr=NULL;
}

