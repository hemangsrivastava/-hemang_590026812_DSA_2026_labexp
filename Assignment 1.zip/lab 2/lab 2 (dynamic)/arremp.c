#include <stdio.h>
#include <stdlib.h>

struct emp{
	int id;
	float sal;
};

int main(){
	int n,i,max;
	struct emp *e;

	printf("Enter no. of employees:");
	scanf("%d",&n);

	e=(struct emp*)malloc(n*sizeof(struct emp));

	for(i=0;i<n;i++){
		printf("Enter id and salary:");
		scanf("%d %f",&e[i].id,&e[i].sal);
	}

	max = 0;
	for(i=1;i<n;i++){
		if(e[i].sal>e[max].sal)
			max = i;
	}

	printf("Highest Salary Employee:\n");
	printf("ID: %d Salary: %.2f", e[max].id,e[max].sal);

	free(e);
	return 0;
}

