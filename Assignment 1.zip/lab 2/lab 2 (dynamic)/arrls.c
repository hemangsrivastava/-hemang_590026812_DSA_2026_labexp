#include <stdio.h>
#include <stdlib.h>

int main(){
	int n,i,max,min;
	int *a;

	printf("Enter no. of elements:");
	scanf("%d",&n);

	a = (int*)malloc(n*sizeof(int));

	for(i=0;i<n;i++){
		printf("Enter element %d:",i+1);
		scanf("%d",&a[i]);
	}

	max=a[0];
	min=a[0];

	for(i=1;i<n;i++){
		if(a[i]>max)
			max=a[i];
		if(a[i]<min)
			min=a[i];
	}

	printf("Largest = %d\n", max);
	printf("Smallest = %d", min);

	free(a);
	return 0;
}

