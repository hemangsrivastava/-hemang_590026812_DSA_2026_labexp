#include <stdio.h>
#include <stdlib.h>

int main(){
	int n,i;
	int *a;

	printf("Enter number of elements:");
	scanf("%d",&n);

	a = (int*)malloc(n*sizeof(int));

	for(i=0;i<n;i++)
	{
		printf("Enter element %d:",i+1);
		scanf("%d",&a[i]);
	}
	printf("Array:\n");
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	free(a);
	return 0;
}

