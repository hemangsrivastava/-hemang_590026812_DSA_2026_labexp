#include <stdio.h>

union data{
	int a;
	float b;
	char c;
};

int main(){
	union data d;

	d.a=10;
	printf("Integer: %d\n",d.a);

	d.b=5.5;
	printf("Float: %.2f\n",d.b);

	d.c='A';
	printf("Char: %c\n",d.c);

	return 0;
}

