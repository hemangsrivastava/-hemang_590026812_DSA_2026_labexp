#include <stdio.h>
#include <stdlib.h>

int main(){
	int n,i,sum=0;
	float avg;
	int *a;

	printf("Enter no. of elements:");
	scanf("%d",&n);

	a = (int*)malloc(n*sizeof(int));

	for(i=0;i<n;i++)
	{
		printf("Enter element %d:",i+1);
		scanf("%d",&a[i]);
		sum=sum+a[i];
	}

	printf("Array:\n");
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}

	avg=sum/(float)n;

	printf("\nSum = %d",sum);
	printf("\nAverage = %.2f",avg);

	free(a);
	return 0;
}

