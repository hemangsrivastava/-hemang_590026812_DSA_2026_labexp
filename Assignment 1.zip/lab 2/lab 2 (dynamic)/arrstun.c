#include <stdio.h>

struct s{
	int a;
	float b;
	char c;
};

union u{
	int a;
	float b;
	char c;
};

int main(){
	printf("Size of structure: %d\n", sizeof(struct s));
	printf("Size of union: %d\n", sizeof(union u));
	return 0;
}

