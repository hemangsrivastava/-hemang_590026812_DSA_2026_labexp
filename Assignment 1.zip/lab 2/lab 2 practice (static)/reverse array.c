#include <stdio.h>
int main(){
	int a,n,i;
	int arr[100];
	printf("enter the length of array: ");
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	printf("the reversed array is: ");
	for(i=n-1;i>=0;i--)
	printf("%d ",arr[i]);
	return 0;
	
}
