#include <stdio.h>
int main(){
	int arr[20][20];
	int n,i,j,total=0;
	float per;
	printf("enter the number of students: ");
	scanf("%d",&n);
	for(i=0;i<n;i++){
		printf("\nStudent %d \n",i+1);
		for(j=0;j<5;j++){
			printf("subject %d: ",j+1);
			scanf("%d",&arr[i][j]);
		}
	}
	for(i=0;i<n;i++){
		printf("total marks percent of student %d: ",i+1);
		for(j=0;j<5;j++){
			total=total+arr[i][j];
			
		}
		per=total/5.0;
		printf("%f\n",per);
		total=0;
	}
	return 0;
}
