#include <stdio.h>
int main(){
	int arr[20];
	int i,n,max,min;
	printf("enter the number of elements: ");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&arr[i]);
	max=arr[0];
	min=arr[0];
	for(i=0;i<n;i++){
		if(arr[i]>max)max=arr[i];	
	}
	for(i=0;i<n;i++){
		if(arr[i]<min)min=arr[i];
	}
	printf("maximum is: %d\n",max);
	printf("minimum is: %d\n",min);
}
