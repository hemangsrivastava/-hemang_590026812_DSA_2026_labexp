#include <stdio.h>
int main(){
	int a,n,i;
	int arr1[20],arr2[20],total[20];
	n=20;
	for(i=0;i<n;i++){
	
	printf("enter the marks of both subjects of student %d:\n",i+1);
	scanf("%d",&arr1[i]);
	scanf("%d",&arr2[i]);
}
	for(i=0;i<n;i++){
		printf("total marks of student %d: ",i+1);
		printf("%d \n",arr1[i]+arr2[i]);
	}
		
	}
